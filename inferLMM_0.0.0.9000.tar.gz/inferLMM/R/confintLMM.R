#' Title main function
#' @param model an object of class varComprob (or varComprob.fit or varComprob.S), lmerMod or rlmerMod
#' @param Data The data.frame object containing the data
#' @param id The grouping variable vector
#' @param Time the time variable vector. It can be adapted for non longitudinal but hierarchical data
#' @param method "parametric" for classical Normal-parametric bootstrap percentile CI, "wild" for the wild  bootstrap percentile CI and "Wald" for z-Wald CI.
#' @param B number of bootstrap samples, positive integer (with "parametric" or "wild") > 1
#' @param level confidence level < 1
#' @param ... S3 object restriction
#' @return A matrix holding columns lower and upper boudaries confidence intervals for each parameter.
#' @import lme4 robustlmm parallel robustvarComp doParallel foreach
#' @export
confintLMM <-
function(model, Data, id, Time, method, B, level,...){


  #Object of class varComprob.S (varComprob with S)
  if(class(model)[1]=="varComprob.S"){
    if(method == "parametric"){
      #source("CIfunction_paramMLS.R")
      result = parametric_S(model = model, id = id, Time = Time, B = B, level = level)
      return(result)
    }
    if(method == "wild"){
      #source("CIfunction_wildMLS.R")
      result = wild_varCompS(model = model, id = id, Time = Time, B = B, level = level)
      return(result)
    }
    if(method == "Wald"){
      summ = summary(model)
      alpha = 1 - level
      inf = c(model$beta - summ$zTable[,2]*qnorm(level+alpha/2),model$eta - sqrt(diag(model$vcov.eta))*qnorm(level+alpha/2))
      sup = c(model$beta + summ$zTable[,2]*qnorm(level+alpha/2),model$eta + sqrt(diag(model$vcov.eta))*qnorm(level+alpha/2))
      result = cbind(inf,sup)
      colnames(result) = c("lower bound", "upper bound")
      return(result)
    }else{
      print("Error! Probably an incorrect value for method argument")
    }
  }

  #Object of class varComprob.compositeTau (varComprob with cTAU)
  if(class(model)[1]=="varComprob.compositeTau"){
    if(method == "parametric"){
      #source("CIfunction_paramMLcTAU.R")
      result = parametric_cTAU(model = model, id = id, Time = Time, B = B, level = level)
      return(result)
    }
    if(method == "wild"){
      #source("CIfunction_wildMLcTAU.R")
      result = wild_varComp(model = model, id = id, Time = Time, B = B, level = level)
      return(result)
    }
    if(method == "Wald"){
      summ = summary(model)
      alpha = 1 - level
      inf = c(model$beta - summ$zTable[,2]*qnorm(level+alpha/2),model$eta - sqrt(diag(model$vcov.eta))*qnorm(level+alpha/2))
      sup = c(model$beta + summ$zTable[,2]*qnorm(level+alpha/2),model$eta + sqrt(diag(model$vcov.eta))*qnorm(level+alpha/2))
      result = cbind(inf,sup)
      colnames(result) = c("lower bound", "upper bound")
      return(result)
    }else{
      print("Error! Probably an incorrect value for method argument")
    }
  }


  #Object of class lmerMod (lmer)
  if(class(model)[1]=="lmerMod"){
    if(method == "parametric"){
    if(model@resp$REML == 0){
      #source("CIfunction_paramML.R")
      result = param_lmerML(model = model, B = B, level = level)
      return(result)
    }else{
      #source("CIfunction_paramREML.R")
      result = param_lmer(model = model, B = B, level = level)
      return(result)
    }
    }
    if(method == "wild"){
      if(model@resp$REML == 0){
        #source("CIfunction_wildML.R")
        result = wild_lmerML(model = model, B = B, level = level)
        return(result)
      }else{
        #source("CIfunction_wildREML.R")
        result = wild_lmer(model = model, B = B, level = level)
        return(result)
      }
    }
    if(method == "Wald"){
        summ=summary(model)
        alpha = 1 - level
        inf = c(fixef(model) - summ$coefficients[,2]*qnorm(level+alpha/2))
        sup = c(fixef(model) + summ$coefficients[,2]*qnorm(level+alpha/2))
        result = cbind(inf,sup)
        colnames(result) = c("lower bound", "upper bound")
        return(result)
    }else{
      print("Error! Probably an incorrect value for method argument")
    }
  }


  #Object of class rlmerMod (rlmer)
  if(class(model)[1]=="rlmerMod"){
    if(method == "parametric"){
      #source("CIfunction_paramML.R")
      result = param_lmerML(model = model, B = B, level = level)
      return(result)
    }
    if(method == "wild"){
      #source("CIfunction_wildML.R")
      result = wild_lmerML(model = model, B = B, level = level)
      return(result)
    }
    if(method == "Wald"){
      summ = summary(model)
      alpha = 1 - level
      inf = c(fixef(model) - summ$coefficients[,2]*qnorm(level+alpha/2))
      sup = c(fixef(model) + summ$coefficients[,2]*qnorm(level+alpha/2))
      result = cbind(inf,sup)
      colnames(result) = c("lower bound", "upper bound")
      return(result)
    }else{
        print("Error! Probably an incorrect value for method argument")
      }
  }


  #Object of class heavyLme
  if(class(model)[1]=="heavyLme"){
    if(method == "parametric"){
      #source("CIfunction_paramNheavyLme.R")
      result = paramN_heavyLme(model = model, Data = Data, B = B, level = level)
      return(result)
    }
    if(method == "t-parametric"){
      #source("CIfunction_paramStheavyLme.R")
      result = paramSt_heavyLme(model = model, Data = Data, B = B, level = level)
      return(result)
    }
    if(method == "wild"){
      #source("CIfunction_wildMLheavyLme.R")
      result = wild_heavyLme(model = model, Data = Data, B = B, level = level)
      return(result)
    }
    if(method == "Wald"){
      summ = summary(model)
      alpha = 1 - level
      inf = c(coefficients(model) - summ$coefficients[,2]*qnorm(level+alpha/2))
      sup = c(coefficients(model) + summ$coefficients[,2]*qnorm(level+alpha/2))
      result = cbind(inf,sup)
      colnames(result) = c("lower bound", "upper bound")
      return(result)
    }else{
      print("Error! Probably an incorrect value for method argument")
    }
  }
}


