require(confintROB)
require(lme4)
require(robustlmm)
require(robustvarComp)

test <- function(object) {
  doTest <- function(method, boot.type) {
    cat(
      "Running test for object of class ",
      class(object),
      " with arguments method = ",
      method,
      " and boot.type = ",
      boot.type,
      "\n"
    )
    set.seed(123)
    result <-
      confintROB(
        object = object,
        parm = NULL,
        level = .95,
        method = method,
        nsim = 10,
        boot.type = boot.type,
        clusterID = "Subject"
      )
    print(result)
  }
  
  for (method in c("boot", "BCa","Wald")) {
    for (boot.type in c("wild", "parametric")) {
      if (method == "Wald" &&
          (boot.type == "wild" | boot.type == "parametric")) {
        # skip
      } else {
        doTest(method, boot.type)
      }
    }
  }
}

model.ML <-
  lmer(Reaction ~ Days + (Days | Subject),
       data = sleepstudy,
       REML = FALSE)
print(summary(model.ML))
test(model.ML)

model.DAStau <-
  rlmer(
    Reaction ~ Days + (Days | Subject),
    data = sleepstudy,
    rho.sigma.e = psi2propII(smoothPsi, k = 2.28),
    rho.b = chgDefaults(smoothPsi, k = 5.14, s = 10),
    rho.sigma.b = chgDefaults(smoothPsi, k = 5.14, s = 10)
  )
print(summary(model.DAStau))
test(model.DAStau)

if (FALSE && require(robustvarComp)) {
  participant <- sleepstudy$Subject
  WITHIN = sleepstudy$Days
  
  # Build the argument "groups" of the varComprob() function
  n = length(unique(participant)) # the number of participants
  J = length(unique(WITHIN)) # the number of repeated observations per participant
  groups = cbind(rep(1:J, each = n), rep((1:n), J)) # a numeric matrix with two columns used to group the observations according to participant.
  
  # Build the argument "varcov" of the varComprob() function
  z1 = rep(1, J) #Value for intercept (=1) for the J observations by clusters
  z2 = unique(WITHIN) # Value for the time variable
  
  K <-
    list(
      # Matrix for intercept
      sigma2_u0 = tcrossprod(z1, z1),
      # Matrix for time variable
      sigma2_u1 = tcrossprod(z2, z2),
      # Matrix of interaction Intercept by time variable
      Covariance = tcrossprod(z1, z2) + tcrossprod(z2, z1)
    )
  
  # Estimation with S-estimator
  model.S <-
    varComprob(
      Reaction ~ 1 + Days,
      groups = groups,
      data = sleepstudy,
      varcov = K,
      control = varComprob.control(
        lower = c(0, 0,-Inf),
        method = "S",
        psi = "rocke"
      )
    )
  print(summary(model.S))
  test(model.S)
  
  # Estimation with composite-TAU estimator
  model.cTAU <- varComprob(
    Reaction ~ 1 + Days,
    groups = groups,
    data = sleepstudy,
    varcov = K,
    control = varComprob.control(lower = c(0, 0,-Inf))
  )
  print(summary(model.cTAU))
  test(model.cTAU)
}
