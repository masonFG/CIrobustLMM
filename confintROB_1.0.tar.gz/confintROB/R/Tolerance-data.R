#' The Tolerance data set
#'
#' Often used for didactic
#' purposes (Singer & Willett, 2003), and originally discussed in Raudenbush and Chan(1992).
#' During five years, once per year (from time = 0 to time = 4), a sample of n = 16
#' children (identified by the variable id, with initial age of 11 years) scored their engagement
#' in nine deviant behaviors, each rated on a four-point scale (from 1 to 4).
#' @format `Tolerance`
#' a data.frame with 8 columns and 80 rows:
#' \describe{
#' \item{X}{row number}
#' \item{id}{participant number}
#' \item{age}{age of the participant}
#' \item{tolerance}{mean of tolerance about deviant behaviors}
#' \item{male}{sex of the participant, 1= male; 0= female}
#' \item{exposure}{exposure to deviant behaviors}
#' \item{time}{year of experiment}
#' \item{group}{children with low exposure (=0) and high exposure (=1) to deviant behaviors}}
#' @docType data
#'
#' @usage data(Tolerance)
#'
#' @keywords datasets
#'
#' @references Raudenbush, S. W., & Chan, W.-S. (1992). Growth curve analysis in accelerated
#' longitudinal designs. Journal of Research in Crime and Delinquency, 29 (4), 387–411.
#' (\href{https://psycnet.apa.org/fulltext/1994-25805-001.html}{google.scholar})
"Tolerance"
