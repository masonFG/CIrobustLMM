#' Title
#' @title confintROB
#' @param object an object of class lmerMod, lmerModLmerTest, rlmerMod, varComprob.compositeTau or varComprob.S
#' @param parm parameters for which intervals are sought. Specified by an integer vector of positions, character vector of parameter names
#' @param level confidence level < 1
#' @param method type of Confidence intervals: "Wald", "boot", "BCa"
#' @param nsim number of bootstrap samples, positive integer
#' @param boot.type type of bootstrap: "wild" or "parametric"
#' @param clusterID text variable indicating the clustering variable
#' @param ... additional options
#'
#' @return Returns Confidence Interval
#' @export
#' @examples
#' library(lme4)
#' model.ML <- lmer(Reaction ~ 1 + Days + (Days|Subject), data = sleepstudy, REML=FALSE)
#' CI.ML <- confintROB(object = model.ML,
#'                     clusterID = "Subject", boot.type = "wild",
#'                     nsim = 10, ## small for speed, in practice use, e.g., 5000
#'                     level = .95)
#' print(CI.ML)
confintROB <-
  function(object,
           parm,
           level,
           method,
           nsim,
           boot.type,
           clusterID,
           ...)
    UseMethod("confintROB")

#' @rdname confintROB
#' @importFrom lme4 confint.merMod
#' @export
confintROB.lmerMod <-
  function(object,
           parm = parm,
           level = .95,
           method = c("boot", "BCa", "Wald"),
           nsim = 50,
           boot.type = c("wild", "parametric"),
           clusterID,
           ...) {
    method <- match.arg(method)
    if (method == "Wald") {
      summ = summary(object)
      alpha = 1 - level
      inf = c(fixef(object) - summ$coefficients[, 2] * qnorm(level +
                                                               alpha / 2))
      sup = c(fixef(object) + summ$coefficients[, 2] * qnorm(level +
                                                               alpha / 2))
      result = cbind(inf, sup)
      colnames(result) = c("lower bound", "upper bound")
      return(result)
    }
    
    resampling <-
      confintLMM(
        model = object,
        id = clusterID,
        method = boot.type,
        B = nsim,
        confint.level = level
      )
    coefs <- resampling$estimation
    
    if (method == "BCa") {
      if (is(class(try(object@frame[clusterID])), "try-error") == TRUE) {
        stop("Argument 'clusterID' is needed for BCa")
      }
      
      idvect 			    = object@frame[clusterID]
      ci_BCa <-
        confint_BCa(
          B = nsim,
          model = object,
          data = object@frame,
          clusterID = idvect,
          coefs,
          confint.level = level
        )
      retVal <- ci_BCa[[1]][parm, , drop = FALSE]
      fullResults <- list(
        BCa = ci_BCa[[1]],
        Percentile = resampling[[2]],
        boot.estimates = coefs,
        biasBCa = ci_BCa[[2]],
        acc = ci_BCa[[3]]
      )
    } else{
      retVal <- resampling[[2]][parm, , drop = FALSE]
      fullResults <-
        list(Percentile = resampling[[2]],
             bootstrap_estimates = coefs)
      if (method != "boot") {
        warning("Argument 'method' was ignored")
      }
    }
    class(fullResults) <- "confintROB-fullResults"
    attr(retVal, "fullResults") <- fullResults
    return(retVal)
  }


#' @importFrom utils packageVersion
#' @rdname confintROB
#' @export
confintROB.rlmerMod <-
  function(object,
           parm = parm,
           level,
           method = c("boot", "BCa", "Wald"),
           nsim,
           boot.type = c("wild", "parametric"),
           clusterID,
           ...) {
    method <- match.arg(method)
    if (packageVersion("robustlmm") < "3.1-1") {
      stop(
        "Please update package 'robustlmm'. In order for 'confintROB' to work",
        "correctly, at least version 3.1-1 is needed."
      )
    }
    confintROB.lmerMod(object,
                       parm,
                       level,
                       method,
                       nsim,
                       boot.type,
                       clusterID,
                       ...)
  }

#' @rdname confintROB
#' @export
confintROB.varComprob <-
  function(object,
           parm = parm,
           level,
           method = c("boot", "BCa", "Wald"),
           nsim,
           boot.type = c("wild", "parametric"),
           clusterID,
           ...) {
    method <- match.arg(method)
    if (method == "Wald") {
      summ = summary(object)
      alpha = 1 - level
      inf = c(
        object$beta - summ$zTable[, 2] * qnorm(level + alpha / 2),
        object$eta - sqrt(diag(object$vcov.eta)) * qnorm(level + alpha / 2)
      )
      sup = c(
        object$beta + summ$zTable[, 2] * qnorm(level + alpha / 2),
        object$eta + sqrt(diag(object$vcov.eta)) * qnorm(level + alpha / 2)
      )
      result = cbind(inf, sup)
      colnames(result) = c("lower bound", "upper bound")
      return(result)
    }
    data <- get(object$call$data, globalenv())
    idvect 			    = data[clusterID]
    resampling <-
      confintLMM(
        model = object,
        id = idvect,
        method = boot.type,
        B = nsim,
        confint.level = level
      )
    
    coefs <- resampling$estimation
    
    if (method == "BCa") {
      if (is(class(try(data[ncol(data)])), "try-error") == TRUE) {
        stop("Argument 'clusterID' is needed for BCa")
      }
      
      ci_BCa <-
        confint_BCaVarComprob(nsim,
                              object,
                              data = data,
                              clusterID = idvect,
                              coefs,
                              level)
      
      result <- list(BCa.interval = ci_BCa)
      if (length(dim(result$BCa.interval)) > 0) {
        colnames(result$BCa.interval) <- c("lower bound", "upper bound")
        row.names(result$BCa.interval) <- colnames(coefs)
      }
      retVal <- as.matrix(result$BCa.interval[parm, , drop = FALSE])
      fullResults <- list(
        result,
        Percentile = resampling[[2]],
        bootestimates = coefs,
        biasBCa = ci_BCa[[2]],
        acc = ci_BCa[[3]]
      )
    } else{
      retVal <- as.matrix(resampling[[2]][parm, , drop = FALSE])
      fullResults <-
        list(Percentile = resampling[[2]], bootestimates = coefs)
      return(retVal)
      if (method != "boot") {
        warning("Argument 'method' was ignored")
      }
    }
    class(fullResults) <- "confintROB-fullResults"
    attr(retVal, "fullResults") <- fullResults
    return(retVal)
  }

#' @export
`print.confintROB-fullResults` <- function(x, ...) {
  cat(
    "  Full results of confintROB, a list with components:\n  ",
    paste("\"", names(x), "\"", collapse = ", ", sep = ""),
    "\n"
  )
  invisible(x)
}
