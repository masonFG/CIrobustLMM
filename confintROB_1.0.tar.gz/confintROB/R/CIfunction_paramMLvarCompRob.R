#Title
# @title Parametric Confidence Interval for varCompRob objects
#
# @param model an object of class varComprob.compositeTau or varComprob.S
# @param id text variable indicating the clustering variable
# @param B number of bootstrap samples, positive integer
# @param confint.level confidence level < 1
# @param max.tries number of times to try to produce a valid model fit
#   before giving up
#
# @return Returns a parametric Confidence Interval for varCompRob objects
#' @importFrom stats rnorm
#' @importFrom methods is
#' @importFrom MASS mvrnorm
# @export
parametric_MLvarCompRob <-
  function(model, id, B, confint.level, max.tries = 100) {
    if (length(model$K) > 1) {
      P 	= 2
    } else{
      P 	= 1
    }
    
    my.DATA 	  = model$model
    #myvar 	    = all.vars(model$terms)
    n_obs 	    = model$nobs
    n_subj      = length(unique(my.DATA$`(groups)`[, 2]))
    matfix 	    = as.matrix(matrix(model$X, n_obs, length(model$fixef)))
    
    if (length(model$K) > 1) {
      Zmatrix 				    = matrix(rep(1, n_obs), nrow = n_obs, ncol = 2)
      
      if (length(model$K) > 2) {
        ranefmatrix 		= matrix(c(model$eta[1], model$eta[3], model$eta[3], model$eta[2]), 2, 2)
        
      } else{
        ranefmatrix 		    = matrix(c(model$eta[1], 0, 0, model$eta[2]), 2, 2)
      }
    } else{
      ranefmatrix 			  = model$eta[1]
      Zmatrix 				    = matrix(rep(1, n_obs), nrow = n_obs, ncol = 1)
    }
    
    bet 		            = unname(model$fixef)
    result 	            = NULL
    resultr 	          = NULL
    `%foreachOp%` <- getForeachOperator()
    resultr = foreach(
      b = 1:B,
      .combine = "rbind",
      .packages = c("MASS", "robustvarComp")
    ) %foreachOp% {
      OK = FALSE
      it <- 0
      
      while (!OK && (it <- it + 1) < max.tries) {
        resr 			  = rnorm(n_obs, 0, sqrt(model$eta0))
        ranefr 		  = mvrnorm(n_subj, rep(0, P), ranefmatrix)
        randomeff 	= data.frame(ranefr)
        randata 		= as.data.frame(randomeff[sort(my.DATA$`(groups)`[, 2]), ])
        ybootr 		= rep(0, n_obs)
        
        
        if (length(model$K) > 1) {
          br 		    = t(randata)
          for (l in 1:n_obs) {
            ybootr[l] = matfix[l, ] %*% bet +  Zmatrix[l, ] %*% br[, l] + resr[l]
          }
        } else {
          br 		    = randata
          for (l in 1:n_obs) {
            ybootr[l] = matfix[l, ] %*% bet  +  Zmatrix[l, ] * br[l] + resr[l]
          }
        }
        
        my.DATA[[as.character(formula(model))[2]]] 	= ybootr
        model.bootr 		=
          try(eval(substitute(update(model, data = data)),
                   list(data = my.DATA)))
        OK <- !is(model.bootr, "try-error")
      }
      
      if (!OK) {
        stop("Failed to produce a valid model fit after ", it, " tries.")
      }
      
      # Estimates on bootsamples
      summb 					= summary(model.bootr)
      bet_boot 				= model.bootr$fixef
      sigma2_boot 		= model.bootr$eta0 ^ 2
      sigma2_random_boot 	= model.bootr$eta
      
      result 				    = c(bet_boot, sigma2_boot, sigma2_random_boot)
    }
    
    results = output_varComp(resultr,
                             confint.level,
                             model)
    return(results)
  }
