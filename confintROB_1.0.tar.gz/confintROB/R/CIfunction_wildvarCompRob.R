# Title
# @title Wild Confidence Interval for varCompRob objects
#
# @param model an object of class varComprob.compositeTau or varComprob.S
# @param id text variable indicating the clustering variable
# @param B number of bootstrap samples, positive integer
# @param confint.level confidence level < 1
# @param max.tries number of times to try to produce a valid model fit
#   before giving up
#
# @return Returns a wild Confidence Interval for varCompRob objects
# @export
wild_MLvarCompRob <-
  function(model, id, B, confint.level, max.tries = 100) {
    # Dataset informations
    my.DATA 	= model$model
    myvar 		= all.vars(model$terms)
    y 			  = as.matrix(my.DATA[myvar[1]])
    effetsfix = names(model$fixef)[-1]
    n_obs     = model$nobs
    matfix 	  = as.matrix(matrix(model$X, n_obs, length(model$fixef)))
    n 			  = nrow(my.DATA)
    
    # Estimates on original sample
    summ 			  = summary(model)
    bet 			  = as.vector(unname(model$fixef))
    est         =  c(bet, model$eta0 ^ 2, model$eta)
    names(est) 	= c(names(model$fixef), "sigma2", names(model$eta))
    
    # Define the probability of weights
    v1 			= -(sqrt(5) - 1) / 2
    v2 			= (sqrt(5) + 1) / 2
    p1 			= (sqrt(5) + 1) / (2 * sqrt(5))
    p2 			= 1 - p1
    
    # Define the disturbances vector for each participant
    rand 		= table(id)
    TT 			= length(rand)
    nt 			= unname(rand)
    n_obs 	= model$nobs
    X 			= as.matrix(matfix)
    XX 			= X
    Xt 			= as.matrix(unname(vector("list", TT)))
    yt 			= as.matrix(vector("list", TT))
    rt_hat 	= as.matrix(vector("list", TT))
    Pt 			= as.matrix(vector("list", TT))
    Int 		= as.matrix(vector("list", TT))
    tXX 		= as.matrix(unname(solve(t(X) %*% X)))
    
    for (i in 1:TT) {
      Xt[[i]] 		= XX[1:nt[i], ]
      XX 					= XX[-(1:nt[i]), ]
      yt[[i]] 		= y[1:nt[i]]
      y 					= y[-(1:nt[i])]
      rt_hat[[i]] = yt[[i]] - Xt[[i]] %*% bet
      Pt[[i]] 		= Xt[[i]] %*% tXX %*% t(Xt[[i]])
      Int[[i]] 		= diag(1, nt[i], nt[i])
    }
    
    # Matrix for results
    rt_b 						        = vector("list", TT)
    yt_b 						        = vector("list", TT)
    
    result 	            = NULL
    resultr 	          = NULL
    `%foreachOp%` <- getForeachOperator()
    resultr = foreach(
      b = 1:B,
      .combine = "rbind",
      .packages = c("MASS", "robustvarComp")
    ) %foreachOp% {
      OK = FALSE
      it <- 0
      
      while (!OK && (it <- it + 1) < max.tries) {
        # Generating the bootsamples observations (y*)
        wt 				= sample(c(v1, v2),
                        TT,
                        replace = TRUE,
                        prob = c(p1, p2))
        
        for (tt in 1:TT) {
          rt_b[[tt]] = sqrt(diag(ginv(Int[[tt]] - Pt[[tt]]))) * rt_hat[[tt]] * wt[tt]
          yt_b[[tt]] = Xt[[tt]] %*% bet + rt_b[[tt]]
        }
        
        # Fitting the bootsample
        yboot 			  = unlist(yt_b)
        my.DATA[[as.character(formula(model))[2]]] 	= yboot
        model.bootr 	=
          try(eval(substitute(update(model, data = data)),
                   list(data = my.DATA)))
        OK <- !is(model.bootr, "try-error")
      }
      
      if (!OK) {
        stop("Failed to produce a valid model fit after ", it, " tries.")
      }
      
      # Estimates on bootsamples
      summb 					= summary(model.bootr)
      bet_boot 				= model.bootr$fixef
      sigma2_boot 		= model.bootr$eta0 ^ 2
      sigma2_random_boot 	= model.bootr$eta
      
      result 				    = c(bet_boot, sigma2_boot, sigma2_random_boot)
    }
    
    # Constructing Percentile Confidence Intervals
    results = output_varComp(resultr,
                             confint.level,
                             model)
    return(results)
  }
