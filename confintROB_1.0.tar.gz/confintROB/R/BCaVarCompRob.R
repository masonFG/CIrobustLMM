# Title
# @title Jackknife estimates
#
# @param model an object of class varComprob.compositeTau or varComprob.S
# @param data an object of class data.frame
# @param clusterID text variable indicating the clustering variable
#
# @return Jackknife estimates
# @export
clusjackVarCompRob <-
  function (model, data, clusterID) {
    summ <- summary(model)
    n_obs <- nrow(data)
    betas <- model$fixef
    
    randoms <- model$eta
    
    estimates <- c(model$fixef, model$eta0, randoms)
    
    names(estimates) <-
      c(names(model$fixef), "sigma2", names(randoms))
    
    p <- length(estimates)
    cluster <- table(clusterID)
    clusters <- unlist(labels(cluster))
    nc <- length(clusters)
    # print(clusters)
    # print(cluster)
    # print(nc)
    coefs <- matrix(NA, nrow = nc, ncol = p)
    Obsno <- split(1:n_obs, model$model$`(groups)`[, 2])
    ii <-
      NULL ## to avoid warning about no visible binding in R CMD check
    `%foreachOp%` <- getForeachOperator()
    coefs = foreach(
      ii = 1:nc,
      .combine = "rbind",
      .packages = c("MASS", "robustvarComp")
    ) %foreachOp% {
      #print(ii)
      obs <- unlist(Obsno[-ii])
      #print(obs)
      i <- which(model$model$`(groups)`[, 2] == ii)
      #print(i)
      groups_i <- model$model$`(groups)`[-i, ]
      #print(model$model$`(groups)`)
      #print(groups_i)
      data_i <- data[obs,]
      #print(data_i)
      modeljack <-
        eval(substitute(
          update(model, data = data, groups = groups),
          list(data = data_i, groups = groups_i)
        ))
      summjack <- summary(modeljack)
      jackcoef <- c(modeljack$fixef, modeljack$eta0, modeljack$eta)
      coef <- as.vector(jackcoef)
    }
    print(coefs)
    colnames(coefs) <- names(estimates)
    uu <- -sweep(coefs, 2, colMeans(coefs, na.rm = T), FUN = "-")
    acc <- rep(NA, p)
    for (i in 1:p) {
      acc[i] <-
        sum(uu[, i] * uu[, i] * uu[, i], na.rm = T) / (6 * (sum(uu[, i] * uu[, i], na.rm =
                                                                  T)) ^ 1.5)
    }
    return(acc)
  }

# Title
# @title BCa Confidence Interval for varCompRob objects
#
# @param B number of bootstrap samples, positive integer
# @param model an object of class varComprob.compositeTau or varComprob.S
# @param data an object of class data.frame
# @param clusterID text variable indicating the clustering variable
# @param coefs matrix of coefficient estimates in the bootstrap samples
# @param confint.level confidence level < 1
#
# @return BCa Confidence Intervals
# @export
confint_BCaVarComprob <-
  function(B,
           model,
           data,
           clusterID,
           coefs,
           confint.level) {
    acc <- clusjackVarCompRob(model, data, clusterID)
    randoms 		= c(model$eta0, model$eta)
    estimates <- c(model$fixef, randoms)
    p <- length(estimates)
    B_alt <- rep(B, p)
    
    biascorr <-
      qnorm(colSums(sweep(coefs, 2, estimates, "-") < 0, na.rm = T) / B_alt)
    tt <- ci_BCa <- matrix(NA, nrow = p, ncol = 2)
    ooo <- NA
    confint.twoprob = c((1 - confint.level) / 2, 1 - (1 - confint.level) /
                          2)
    confint.twolevels = qnorm(confint.twoprob)
    for (i in 1:p) {
      tt[i,] <-
        as.vector(pnorm(biascorr[i] + (biascorr[i] + confint.twolevels) / (
          1 - acc[i] * (biascorr[i] + confint.twolevels)
        )))
      ooo <- trunc(tt[i,] * B_alt[i])
      tryCatch(
        ci_BCa[i,] <-
          sort(coefs[, i])[ooo],
        error = function(e) {
          ci_BCa[i,] <- c(NA, NA)
        }
      )
    }
    colnames(ci_BCa) 				= c("lower bound", "upper bound")
    row.names(ci_BCa) = names(estimates)
    return(list(ci_BCa, biascorr, acc))
  }
