# Title
# @title Parametric Confidence Interval for lmerMod objects
#
# @param model an object of class lmerMod, lmerModLmerTest
# @param B number of bootstrap samples, positive integer
# @param confint.level confidence level < 1
#
# @return Returns a parametric Confidence Interval for merMod objects
#' @importFrom stats simulate formula quantile
#' @importFrom lme4 lmer
# @export
param <-
  function(model, B, confint.level) {
    bdd 			  <- model@frame
    resultr <- NULL
    #bootstrap
    `%foreachOp%` <- getForeachOperator()
    resultr = foreach(
      b = 1:B,
      .combine = "rbind",
      .packages = c("MASS", "lme4")
    ) %foreachOp% {
      OK                   <- FALSE
      
      while (!OK) {
        # Fitting the bootsample
        class(model) <- "lmerMod"
        bdd$yboot 			= unlist(simulate(model, 1, use.u = T))
        formulrest 			= as.character(formula(model))[3]
        formulboot 			= paste("yboot ~", formulrest)
        model.bootr 		= lmer(formulboot, data = bdd, REML = F)
        
        if (length(model.bootr@optinfo$conv$lme4$messages) == 0) {
          OK = TRUE
        }
      }
      
      # Estimates on bootsamples
      summb 					= summary(model.bootr)
      bet_boot 				= fixef(model.bootr)
      sigma_boot 		= as.data.frame(VarCorr(model.bootr))
      
      result 		        = c(bet_boot, sigma_boot[, 5])
    }
    
    # Constructing Percentile Confidence Intervals
    results 					=  output(resultr, confint.level, model)
    return(results)
  }
