# Title
# @title Confidence Interval for rlmerMod, lmerModLmerTest, rlmerMod, varComprob.compositeTau or varComprob.S objects
#
# @param model an object of class lmerMod, lmerModLmerTest, rlmerMod, varComprob.compositeTau or varComprob.S
# @param id text variable indicating the clustering variable
# @param method type of Confidence intervals: "parametric" or "wild" are possible
# @param B number of bootstrap samples, positive integer
# @param confint.level confidence level < 1
# @param ... additional options
# @return Returns a Confidence Interval
# @export
confintLMM <-
  function(model,
           id,
           method,
           B,
           confint.level,
           ...) {
    #Object of class varComprob.S (varComprob with S) or class varComprob.compositeTau (varComprob with cTAU)
    if (is(model, "varComprob.S") |
        is(model, "varComprob.compositeTau")) {
      if (method == "parametric") {
        result = parametric_MLvarCompRob(
          model = model,
          id = id,
          B = B,
          confint.level = confint.level
        )
        return(result)
      }
      if (method == "wild") {
        result = wild_MLvarCompRob(
          model = model,
          id = id,
          B = B,
          confint.level = confint.level
        )
        return(result)
      } else{
        print("Error! Probably an incorrect value for method argument")
      }
    }
    
    #Object of class lmerMod (lmer)
    if (is(model, "lmerModLmerTest") |
        is(model, "lmerMod") |
        is(model, "rlmerMod")) {
      if (method == "parametric") {
        result = param(model = model,
                       B = B,
                       confint.level = confint.level)
        return(result)
      }
      if (method == "wild") {
        result = wild(model = model,
                      B = B,
                      confint.level = confint.level)
        return(result)
      } else{
        print("Error! Probably an incorrect value for method argument")
      }
    } else{
      print("Error! class object must be rlmerMod or lmerModLmerTest or lmerMod or varComprob")
    }
  }

# Title
#
# @param resultr bootstrap estimates
# @param confint.level confidence level < 1
# @param model  an object of class lmerMod, lmerModLmerTest, rlmerMod
#
# @return estimates in bootstrap and CIs
#' @importFrom tidyr replace_na
# @export
output <- function(resultr,
                   confint.level,
                   model) {
  results 					= resultr
  J 						    = dim(results)[2]
  estim 					  = NULL
  
  for (j in 1:J) {
    estim 					= c(estim, unname(quantile(
      results[, j], (1 - confint.level) / 2, na.rm = T
    )), unname(quantile(results[, j], (
      1 - (1 - confint.level) / 2
    ), na.rm = T)))
  }
  
  CI 						    = t(matrix(estim, 2, J))
  
  randoms 	<- as.data.frame(VarCorr(model))
  names_randoms <-
    paste("Sigma",
          replace_na(unlist(randoms[, 1]), ""),
          replace_na(unlist(randoms[, 2]), ""),
          replace_na(unlist(randoms[, 3]), ""))
  
  row.names(CI) <- c(names(fixef(model)), names_randoms)
  bootestimates <- results
  colnames(bootestimates) <- row.names(CI)
  
  colnames(CI) 		  = c("lower bound", "upper bound")
  return(list(estimation = bootestimates, CI))
}





# Title output_varComp
#
# @param resultr bootstrap estimates
# @param confint.level confidence level < 1
# @param model an object of class varComprob
# #@return estimates in bootstrap and CIs
# @export
output_varComp <- function(resultr,
                   confint.level,
                   model) {
  results 					= resultr
  J 						    = dim(results)[2]
  estim 					  = NULL
  
  for (j in 1:J) {
    estim 					= c(estim, unname(quantile(
      results[, j], (1 - confint.level) / 2, na.rm = T
    )), unname(quantile(results[, j], (
      1 - (1 - confint.level) / 2
    ), na.rm = T)))
  }

  
  CI 						    = t(matrix(estim, 2, J))
  
  row.names(CI) = c(names(model$fixef), "sigma2", names(model$eta))
  
  colnames(CI) 	  = c("lower bound", "upper bound")
  return(list(estimation = results, CI))
}




# Title
#
# @return dopar or do function
# @export
#
# @examples
getForeachOperator <- function() {
  if (foreach::getDoParRegistered()) {
    return(foreach::`%dopar%`)
  } else {
    return(foreach::`%do%`)
  }
}