# Title
# @title Jackknife estimates
#
# @param model an object of class lmerMod or lmerModLmerTest
# @param data an object of class data.frame
# @param clusterID text variable indicating the clustering variable
#
# @return Jackknife estimates and accelerated parameter
#' @importFrom lme4 fixef VarCorr
#' @importFrom stats update
#' @importFrom tidyr replace_na
#' @importFrom foreach `%dopar%` foreach
# @export
clusjack <-
  function (model, data, clusterID) {
    summ <- summary(model)
    n <- nrow(data)
    betas <- fixef(model)
    
    randoms 		<- as.data.frame(VarCorr(model))
    
    estimates <- c(fixef(model), randoms[, 5])
    names_randoms <-
      paste("Sigma",
            replace_na(unlist(randoms[, 1]), ""),
            replace_na(unlist(randoms[, 2]), ""),
            replace_na(unlist(randoms[, 3]), ""))
    names(estimates) <- c(names(fixef(model)), names_randoms)
    
    p <- length(estimates)
    coefs <- NULL
    cluster <- table(clusterID)
    clusters <- unlist(labels(cluster))
    nc <- length(clusters)
    
    Obsno <- unlist(split(1:n, cluster))
    
    if (class(model)[1] == "rlmerMod") {
      coefs = jackesampling_rlmer(nc, Obsno, model, data)
    } else{
      coefs = jackesampling_lmer(nc, Obsno, model, data)
    }
    
    colnames(coefs) <- names(estimates)
    uu <- -sweep(coefs, 2, colMeans(coefs, na.rm = T), FUN = "-")
    acc <- rep(NA, p)
    for (i in 1:p) {
      acc[i] <-
        sum(uu[, i] * uu[, i] * uu[, i], na.rm = T) / (6 * (sum(uu[, i] * uu[, i], na.rm =
                                                                  T)) ^ 1.5)
    }
    names(acc) <- c(names(fixef(model)), names_randoms)
    return(acc)
  }



# Title
# @title estimates on Jacknife samples with lmer
#
# @param nc length of the cluster ID
# @param Obsno index of the clusers
# @param model an object of class lmerMod or lmerModLmerTest
# @param data an object of class data.frame
#
# @return Jackknife lmer estimates
# @export
jackesampling_lmer <-
  function(nc, Obsno, model, data) {
    i <- NULL ## Make R CMD check happy
    `%foreachOp%` <- getForeachOperator()
    foreach(
      i = 1:nc,
      .combine = "rbind",
      .packages = c("MASS", "lme4")
    ) %foreachOp% {
      obs <- unlist(Obsno[-i])
      modeljack <- update(model, data = data[obs,])
      summjack <- summary(modeljack)
      
      jackcoef <-
        c(fixef(modeljack), as.data.frame(VarCorr(modeljack))[, 5])
      
      coef <- as.vector(jackcoef)
    }
  }

# Title
# @title estimates on Jacknife samples with rlmer
#
# @param nc length of the cluster ID
# @param Obsno index of the clusers
# @param model an object of class rlmerMod
# @param data an object of class data.frame
#
# @return Jackknife rlmer estimates
# @export
jackesampling_rlmer <-
  function(nc, Obsno, model, data) {
    i <- NULL ## Make R CMD check happy
    `%foreachOp%` <- getForeachOperator()
    foreach(
      i = 1:nc,
      .combine = "rbind",
      .packages = c("MASS", "robustlmm")
    ) %foreachOp% {
      obs <- unlist(Obsno[-i])
      modeljack <- update(model, data = data[obs,])
      summjack <- summary(modeljack)
      
      jackcoef <-
        c(fixef(modeljack), as.data.frame(VarCorr(modeljack))[, 5])
      
      coef <- as.vector(jackcoef)
    }
  }

# Title
# @title BCa Confidence Interval for lmerMod objects
#
# @param B number of bootstrap samples, positive integer
# @param model an object of class lmerMod or lmerModLmerTest
# @param data an object of class data.frame
# @param clusterID text variable indicating the clustering variable
# @param confint.level confidence level < 1
# @param coefs matrix of coefficient estimates in the bootstrap samples
#
# @return BCa Confidence Interval
#' @importFrom stats qnorm pnorm
# @export
confint_BCa <-
  function(B,
           model,
           data,
           clusterID,
           coefs,
           confint.level) {
    acc <- clusjack(model, data, clusterID)
    randoms 		= as.data.frame(VarCorr(model))
    estimates <- c(fixef(model), randoms[, 5])
    names_randoms <-
      paste("Sigma",
            replace_na(unlist(randoms[, 1]), ""),
            replace_na(unlist(randoms[, 2]), ""),
            replace_na(unlist(randoms[, 3]), ""))
    names(estimates) <- c(names(fixef(model)), names_randoms)
    p <- length(estimates)
    B_alt <- rep(B, p)
    biascorr <-
      qnorm(colSums(sweep(coefs, 2, estimates, "-") < 0, na.rm = T) / B_alt) #remplacé B_alt par length(unique(clusterID))?
    tt <- ci_BCa <- matrix(NA, nrow = p, ncol = 2)
    ooo <- NA
    confint.twoprob = c((1 - confint.level) / 2, 1 - (1 - confint.level) /
                          2)
    confint.twolevels = qnorm(confint.twoprob)
    for (i in 1:p) {
      tt[i,] <-
        as.vector(pnorm(biascorr[i] + (biascorr[i] + confint.twolevels) / (
          1 - acc[i] * (biascorr[i] + confint.twolevels)
        )))
      ooo <- trunc(tt[i,] * B_alt[i])
      tryCatch(
        ci_BCa[i,] <-
          sort(coefs[, i])[ooo],
        error = function(e) {
          ci_BCa[i,] <- c(NA, NA)
        }
      )
    }
    colnames(ci_BCa) 				= c("lower bound", "upper bound")
    row.names(ci_BCa) =  c(names(fixef(model)), names_randoms)
    return(list(ci_BCa, biascorr, acc))
  }