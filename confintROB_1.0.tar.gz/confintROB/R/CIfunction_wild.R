# Title
# @title Wild Confidence Interval for lmerMod objects
#
# @param model an object of class lmerMod or lmerModLmerTest
# @param B number of bootstrap samples, positive integer
# @param confint.level confidence level < 1
#
# @return Returns a wild Confidence Interval for lmerMod or lmerModLmerTest objects
#' @importFrom stats model.matrix terms
#' @importFrom foreach `%dopar%` foreach
# @export
wild <-
  function(model, B, confint.level) {
    bdd 			  = model@frame
    y 			    = model@resp$y
    
    nomID 		  = names(summary(model)$ngrps)[1]
    id 			    = bdd[nomID]
    summ 			  = summary(model)
    n 			    = nrow(bdd)
    bet 			  = as.vector(unname(fixef(model)))
    
    v1 			= -(sqrt(5) - 1) / 2
    v2 			= (sqrt(5) + 1) / 2
    p1 			= (sqrt(5) + 1) / (2 * sqrt(5))
    p2 			= 1 - p1
    rand 		= table(id)
    TT 			= length(rand)
    nt 			= unname(rand)
    X 			= matrix(1, n, 1)
    reg 		= attr(terms(formula(model)), "term.labels")
    X 			= model.matrix(model, data = as.data.frame(bdd[, reg]))
    XX 			= as.matrix(unname(X))
    Xt 			= as.matrix(unname(vector("list", TT)))
    yt 			= as.matrix(vector("list", TT))
    rt_hat 	= as.matrix(vector("list", TT))
    Pt 			= as.matrix(vector("list", TT))
    Int 		= as.matrix(vector("list", TT))
    tXX 		= as.matrix(unname(solve(t(X) %*% X)))
    
    for (i in 1:TT) {
      if (!is.vector(XX)) {
        if (is.vector(XX[1:nt[i],])) {
          Xt[[i]] 	  =  t(as.matrix(XX[1:nt[i],]))
        } else{
          Xt[[i]] =  XX[1:nt[i],]
        }
        XX 			    = XX[-(1:nt[i]),]
        yt[[i]] 	  = y[1:nt[i]]
        y 			    = y[-(1:nt[i])]
        rt_hat[[i]] = yt[[i]] - Xt[[i]] %*% bet
        Pt[[i]] 	  = Xt[[i]] %*% tXX %*% t(Xt[[i]])
        Int[[i]] 	  = diag(1, nt[i], nt[i])
      } else{
        Xt[[i]] 	  =  t(as.matrix(XX))
        yt[[i]] 	  = y[1:nt[i]]
        y 			    = y[-(1:nt[i])]
        rt_hat[[i]] = yt[[i]] - Xt[[i]] %*% bet
        Pt[[i]] 	  = Xt[[i]] %*% tXX %*% t(Xt[[i]])
        Int[[i]] 	  = diag(1, nt[i], nt[i])
      }
    }
    
    rt_b 			    = vector("list", TT)
    yt_b 			    = vector("list", TT)
    
    result 	            = NULL
    resultr 	          = NULL
    `%foreachOp%` <- getForeachOperator()
    if (class(model)[1] == "rlmerMod") {
      resultr = foreach(
        b = 1:B,
        .combine = "rbind",
        .packages = c("MASS", "robustlmm")
      ) %foreachOp% {
        result = bootstrap_estimates(v1,
                                     v2,
                                     TT,
                                     p1,
                                     p2,
                                     Int,
                                     Pt,
                                     rt_b,
                                     rt_hat,
                                     Xt,
                                     bet,
                                     bdd,
                                     model,
                                     yt_b)
        
      }
    } else{
      resultr = foreach(
        b = 1:B,
        .combine = "rbind",
        .packages = c("MASS", "lme4")
      ) %foreachOp% {
        result = bootstrap_estimates(v1,
                                     v2,
                                     TT,
                                     p1,
                                     p2,
                                     Int,
                                     Pt,
                                     rt_b,
                                     rt_hat,
                                     Xt,
                                     bet,
                                     bdd,
                                     model,
                                     yt_b)
        
      }
    }
    
    # Constructing Percentile Confidence Intervals
    results 					=  output(resultr, confint.level, model)
    return(results)
  }



# Title
# @title Wild bootstrap estimates
#
# @param v1 first possible value for weights in the wild bootstrap
# @param v2 second possible value for weights in the wild bootstrap
# @param TT length of cluster ID
# @param p1 probability associated to v1
# @param p2 probability associated to v2
# @param Int matrix I
# @param Pt orthogonal projection
# @param rt_hat bootstrap residuals
# @param Xt design matrix for fixed effects
# @param bet vector of fixed effects
# @param bdd dataset
# @param model an object of class rlmerMod or lmerMod
# @param rt_b emplacement for resiudals
# @param yt_b emplacement for y bootstrap
#
# @return bootstrap estimates
#' @importFrom MASS ginv
# @export
bootstrap_estimates <-
  function(v1,
           v2,
           TT,
           p1,
           p2,
           Int,
           Pt,
           rt_b,
           rt_hat,
           Xt,
           bet,
           bdd,
           model,
           yt_b) {
    OK = FALSE
    
    while (!OK) {
      wt = sample(c(v1, v2),
                  TT,
                  replace = TRUE,
                  prob = c(p1, p2))
      
      for (tt in 1:TT) {
        rt_b[[tt]] = sqrt(diag(ginv(Int[[tt]] - Pt[[tt]]))) * rt_hat[[tt]] * wt[tt]
        yt_b[[tt]] = Xt[[tt]] %*% bet + rt_b[[tt]]
      }
      
      yboot 				= unlist(yt_b)
      bdd$yboot 		= yboot
      formulrest 		= as.character(formula(model))[3]
      formulboot 		= paste("yboot ~", formulrest)
      model.bootr 	= lmer(formulboot, data = bdd, REML = F)
      
      if (length(model.bootr@optinfo$conv$lme4$messages) == 0) {
        OK = TRUE
      }
    }
    
    summb 					= summary(model.bootr)
    bet_boot 				= fixef(model.bootr)
    sigma_boot 		= as.data.frame(VarCorr(model.bootr))
    
    result 		        = c(bet_boot, sigma_boot[, 5])
    
    return(result)
  }
